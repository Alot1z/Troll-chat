# TrollChat
Offline CLI-based LLM chat client for iOS (TrollStore)