#include <stdio.h>
#include <dirent.h>
int main() {
    printf("Available models:\n");
    struct dirent *d; DIR *dir = opendir("models");
    while ((d = readdir(dir)) != NULL) if (d->d_type == DT_REG) printf(" - %s\n", d->d_name);
    closedir(dir);
    return 0;
}
